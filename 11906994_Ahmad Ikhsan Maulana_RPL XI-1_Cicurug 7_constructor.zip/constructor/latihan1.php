<?php 
	//Jualan Pakaian
	//Celana
	//Baju
	//Hoodie
	class Pakaian {
		public $warna,
			   $ukuran,
			   $bahan,
			   $harga;

		public function __construct($warna,$ukuran,$bahan,$harga) {
			$this->warna = $warna;
			$this->ukuran = $ukuran;
			$this->bahan = $bahan;
			$this->harga = $harga; 

		}

		public function getbuy(){
			return "$this->warna,$this->ukuran,
			        $this->bahan,$this->harga";
		}

		
	}

	$celana = new Pakaian("Navy", "L", "Waterproof", 50000);
	$baju = new Pakaian("Hijau","XL", "Katun", 75000);
	$hoodie = new Pakaian("Hitam","M", "Fleece", 175000);


	echo "Celana : ". $celana->getbuy();
	echo "<br>";
	echo "Baju   : ". $baju->getbuy();
	echo "<br>";
	echo "Hoodie : ". $hoodie->getbuy();



 ?>